package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import source.PalindromeWord;

public class PalindromeWordTest {
	PalindromeWord sp=null;
	@Before
	public void setUp() throws Exception {
		sp=new PalindromeWord();
	}

	@Test
	public void PalindTest() {
		assertEquals(false,PalindromeWord.isPalindrome("ramajhbjgj"));
		assertEquals(true,PalindromeWord.isPalindrome("madam"));
		assertTrue("yes this is plyndrome",PalindromeWord.isPalindrome("madam"));
		assertFalse("You not Entered String",PalindromeWord.isPalindrome("ramajhbjgj"));
		
	}

}
